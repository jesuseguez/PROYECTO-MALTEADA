<?php
require_once __DIR__ . '/../config/auth.php';
if (!isLoggedIn()) { header("Location: ../login.php"); exit; }

require_once __DIR__ . '/../config/database.php';

// Obtener todos los productos
$stmt = $pdo->query("SELECT * FROM productos ORDER BY id DESC");
$productos = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <?php 
  require_once __DIR__ . '/../config/config.php';
  $pageTitle = 'Productos · ' . SITE_NAME; 
  include __DIR__ . '/../includes/head.php'; 
  ?>
  <style>
    body { margin: 0; overflow: hidden; background: var(--color-surface-muted); }
    .admin-layout { display: grid; grid-template-columns: 280px 1fr; height: 100vh; }
    .admin-sidebar { background: var(--color-primary); color: #fff; padding: 2rem 1.5rem; display: flex; flex-direction: column; height: 100%; overflow-y: auto; }
    .admin-nav-link { display: flex; align-items: center; gap: 0.75rem; padding: 1rem; color: var(--color-primary-glow); text-decoration: none; font-size: 0.9rem; font-weight: 500; transition: all 0.3s; border-radius: 4px; }
    .admin-nav-link:hover, .admin-nav-link.active { background: rgba(255,255,255,0.1); color: #fff; }
    .admin-content { padding: 3rem; height: 100vh; overflow-y: auto; }
    .admin-table { width: 100%; border-collapse: collapse; text-align: left; background: #fff; border: 1px solid var(--color-line); }
    .admin-table th { padding: 1rem; font-size: 0.75rem; text-transform: uppercase; color: var(--color-ink-soft); border-bottom: 1px solid var(--color-line); }
    .admin-table td { padding: 1rem; border-bottom: 1px solid var(--color-surface-muted); vertical-align: middle; }
  </style>
</head>
<body>
  <div class="admin-layout">
    
    <?php include __DIR__ . '/sidebar.php'; ?>

    <main class="admin-content">
      <header style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 3rem;">
        <div>
          <span class="eyebrow">Catálogo</span>
          <h1 style="font-family: var(--font-display); font-size: 2.5rem; color: var(--color-primary); margin: 0.5rem 0;">Gestión de Productos</h1>
        </div>
        <a href="productos_crear.php" class="btn" style="background: var(--color-primary); color: #fff; border: none; padding: 0.75rem 1.5rem;">
          <span class="material-symbols-outlined">add</span> Nuevo Producto
        </a>
      </header>

      <div style="background: #fff; border: 1px solid var(--color-line);">
        <table class="admin-table">
          <thead>
            <tr>
              <th>Imagen</th>
              <th>Nombre</th>
              <th>Categoría</th>
              <th>Precio</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($productos)): ?>
              <tr><td colspan="5" style="text-align: center; padding: 2rem;">No hay productos registrados aún.</td></tr>
            <?php else: ?>
              <?php foreach ($productos as $p): ?>
                <tr>
                  <td><img src="../assets/uploads/<?= htmlspecialchars($p['imagen']) ?>" alt="Img" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;"></td>
                  <td style="font-weight: 600;"><?= htmlspecialchars($p['nombre']) ?></td>
                  <td><span style="font-size: 0.75rem; background: var(--color-surface-muted); padding: 0.25rem 0.5rem; border-radius: 4px;"><?= htmlspecialchars($p['categoria']) ?></span></td>
                  <td><?= number_format($p['precio'], 2) ?> Bs.</td>
                  <td>
                    <a href="productos_editar.php?id=<?= $p['id'] ?>" style="color: var(--color-primary); text-decoration: none; font-size: 0.85rem; font-weight: 600; margin-right: 1rem;">Editar</a>
                    <a href="productos_eliminar.php?id=<?= $p['id'] ?>" style="color: #ba1a1a; text-decoration: none; font-size: 0.85rem; font-weight: 600;" onclick="return confirm('¿Eliminar producto?');">Eliminar</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</body>
</html>
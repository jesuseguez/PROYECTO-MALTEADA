<?php
require_once __DIR__ . '/../config/auth.php';
if (!isLoggedIn()) { header("Location: ../login.php"); exit; }

require_once __DIR__ . '/../config/database.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $precio = trim($_POST['precio'] ?? '');
    $categoria = trim($_POST['categoria'] ?? '');
    $badge = trim($_POST['badge'] ?? '');
    
    // Manejo de la imagen
    $imagenNombre = '';
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['imagen']['tmp_name'];
        $fileName = $_FILES['imagen']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        // Generar nombre único para evitar sobreescribir
        $nuevoNombre = uniqid('prod_') . '.' . $fileExtension;
        $uploadFileDir = __DIR__ . '/../assets/uploads/';
        $dest_path = $uploadFileDir . $nuevoNombre;
        
        // Permitir solo ciertos formatos
        $allowedfileExtensions = array('jpg', 'jpeg', 'png', 'webp');
        if (in_array($fileExtension, $allowedfileExtensions)) {
            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                $imagenNombre = $nuevoNombre;
            } else {
                $error = 'Error al mover la imagen a la carpeta. Verifica permisos.';
            }
        } else {
            $error = 'Formato de imagen no permitido. Usa JPG, PNG o WEBP.';
        }
    } else {
        $error = 'Debes subir una imagen.';
    }

    if (!$error) {
        $sql = "INSERT INTO productos (nombre, descripcion, precio, categoria, imagen, badge) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        
        if ($stmt->execute([$nombre, $descripcion, $precio, $categoria, $imagenNombre, $badge])) {
            $success = 'Producto creado exitosamente.';
        } else {
            $error = 'Error al guardar en la base de datos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <?php 
  require_once __DIR__ . '/../config/config.php';
  $pageTitle = 'Crear Producto · ' . SITE_NAME; 
  include __DIR__ . '/../includes/head.php'; 
  ?>
  <style>
    body { margin: 0; overflow: hidden; background: var(--color-surface-muted); }
    .admin-layout { display: grid; grid-template-columns: 280px 1fr; height: 100vh; }
    .admin-sidebar { background: var(--color-primary); color: #fff; padding: 2rem 1.5rem; display: flex; flex-direction: column; height: 100%; overflow-y: auto; }
    .admin-nav-link { display: flex; align-items: center; gap: 0.75rem; padding: 1rem; color: var(--color-primary-glow); text-decoration: none; font-size: 0.9rem; font-weight: 500; transition: all 0.3s; border-radius: 4px; }
    .admin-nav-link:hover, .admin-nav-link.active { background: rgba(255,255,255,0.1); color: #fff; }
    .admin-content { padding: 3rem; height: 100vh; overflow-y: auto; }
    .form-group { margin-bottom: 1.5rem; }
    .form-group label { display: block; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft); margin-bottom: 0.5rem; }
    .form-control { width: 100%; padding: 1rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; font-family: var(--font-body); font-size: 0.95rem; }
  </style>
</head>
<body>
  <div class="admin-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>

    <main class="admin-content">
      <header style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 3rem;">
        <div>
          <span class="eyebrow">Catálogo</span>
          <h1 style="font-family: var(--font-display); font-size: 2.5rem; color: var(--color-primary); margin: 0.5rem 0;">Nuevo Producto</h1>
        </div>
        <a href="productos.php" class="btn btn--ghost" style="border-color: var(--color-line-strong); padding: 0.75rem 1.5rem;">Volver a la lista</a>
      </header>

      <?php if ($error): ?><div style="background: #ffdad6; color: #93000a; padding: 1rem; margin-bottom: 2rem;"><?= $error ?></div><?php endif; ?>
      <?php if ($success): ?><div style="background: #d1e7dd; color: #0f5132; padding: 1rem; margin-bottom: 2rem;"><?= $success ?></div><?php endif; ?>

      <div style="background: #fff; border: 1px solid var(--color-line); padding: 3rem; max-width: 800px;">
        <form method="POST" action="" enctype="multipart/form-data">
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
            <div class="form-group">
              <label>Nombre del Producto *</label>
              <input type="text" name="nombre" class="form-control" required>
            </div>
            <div class="form-group">
              <label>Precio (Bs.) *</label>
              <input type="number" step="0.01" name="precio" class="form-control" required>
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
            <div class="form-group">
              <label>Catálogo / Categoría *</label>
              <select name="categoria" class="form-control" required>
                <option value="tradicionales">Tradicionales</option>
                <option value="frutas">Frutas Chiquitanas</option>
                <option value="temporada">Ediciones de Temporada</option>
                <option value="helados">Helados & Copas</option>
                <option value="combos">Combos & Paquetes</option>
                <option value="veganas">Veganas</option>
              </select>
            </div>
            <div class="form-group">
              <label>Etiqueta / Badge (Opcional)</label>
              <input type="text" name="badge" class="form-control" placeholder="Ej. Favorita, Nuevo, Limitada...">
            </div>
          </div>

          <div class="form-group">
            <label>Descripción *</label>
            <textarea name="descripcion" rows="4" class="form-control" required></textarea>
          </div>

          <div class="form-group">
            <label>Imagen del Producto *</label>
            <input type="file" name="imagen" class="form-control" accept="image/*" required>
            <small style="color: var(--color-ink-soft); display: block; margin-top: 0.5rem;">Formatos permitidos: JPG, PNG, WEBP.</small>
          </div>

          <button type="submit" class="btn" style="background: var(--color-primary); color: #fff; border: none; padding: 1.2rem 3rem; margin-top: 1rem;">Guardar Producto</button>
        </form>
      </div>
    </main>
  </div>
</body>
</html>
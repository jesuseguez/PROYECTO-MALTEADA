<?php
require_once __DIR__ . '/../config/auth.php';
if (!isLoggedIn()) { header("Location: ../login.php"); exit; }

require_once __DIR__ . '/../config/database.php';

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM mensajes WHERE id = ?");
    $stmt->execute([$id]);
}

header("Location: mensajes.php");
exit;
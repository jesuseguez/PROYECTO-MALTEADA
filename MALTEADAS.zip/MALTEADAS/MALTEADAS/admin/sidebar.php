<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<aside class="admin-sidebar">
  <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 3rem; padding: 0 0.5rem;">
    <span style="width: 2.5rem; height: 2.5rem; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.1); color: var(--color-secondary); border-radius: 4px;">
      <span class="material-symbols-outlined">icecream</span>
    </span>
    <div style="display: flex; flex-direction: column; line-height: 1.1;">
      <span style="font-family: var(--font-display); font-size: 1.5rem; font-weight: 600; color: #fff;">Curupau</span>
      <span style="font-size: 0.6rem; text-transform: uppercase; letter-spacing: 0.15em; color: var(--color-secondary);">Admin</span>
    </div>
  </div>
  
  <span style="font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-secondary); padding: 0 1rem; margin-bottom: 1rem;">Administración</span>
  
  <a href="dashboard.php" class="admin-nav-link <?= $currentPage == 'dashboard.php' ? 'active' : '' ?>">
    <span class="material-symbols-outlined">dashboard</span> Dashboard
  </a>
  
  <a href="productos.php" class="admin-nav-link <?= $currentPage == 'productos.php' ? 'active' : '' ?>">
    <span class="material-symbols-outlined">icecream</span> Productos
  </a>
  
  <a href="mensajes.php" class="admin-nav-link <?= $currentPage == 'mensajes.php' ? 'active' : '' ?>">
    <span class="material-symbols-outlined">mail</span> Mensajes
  </a>
    
  <div style="margin-top: auto; padding-top: 2rem;">
    <a href="../index.php" class="admin-nav-link" style="color: var(--color-primary-glow); margin-bottom: 0.5rem;">
      <span class="material-symbols-outlined">storefront</span> Ir a la Tienda
    </a>
    <a href="../logout.php" class="admin-nav-link" style="color: #ffb5a1;">
      <span class="material-symbols-outlined">logout</span> Cerrar Sesión
    </a>
  </div>
</aside>
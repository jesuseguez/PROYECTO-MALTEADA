<?php
require_once __DIR__ . '/../config/auth.php';
if (!isLoggedIn()) { header("Location: ../login.php"); exit; }

require_once __DIR__ . '/../config/database.php';

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: productos.php"); exit; }

// Obtener el producto actual
$stmt = $pdo->prepare("SELECT * FROM productos WHERE id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) { header("Location: productos.php"); exit; }

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $precio = trim($_POST['precio'] ?? '');
    $categoria = trim($_POST['categoria'] ?? '');
    $badge = trim($_POST['badge'] ?? '');
    
    $imagenNombre = $p['imagen']; // Por defecto, mantener la actual
    
    // Si se sube una nueva imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['imagen']['tmp_name'];
        $fileExtension = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
        $nuevoNombre = uniqid('prod_') . '.' . $fileExtension;
        $uploadFileDir = __DIR__ . '/../assets/uploads/';
        
        if (in_array($fileExtension, array('jpg', 'jpeg', 'png', 'webp'))) {
            if (move_uploaded_file($fileTmpPath, $uploadFileDir . $nuevoNombre)) {
                // Eliminar la imagen vieja si existe
                if ($p['imagen'] && file_exists($uploadFileDir . $p['imagen'])) {
                    unlink($uploadFileDir . $p['imagen']);
                }
                $imagenNombre = $nuevoNombre;
            }
        } else {
            $error = 'Formato de imagen no permitido.';
        }
    }

    if (!$error) {
        $sql = "UPDATE productos SET nombre=?, descripcion=?, precio=?, categoria=?, imagen=?, badge=? WHERE id=?";
        $stmt = $pdo->prepare($sql);
        if ($stmt->execute([$nombre, $descripcion, $precio, $categoria, $imagenNombre, $badge, $id])) {
            $success = 'Producto actualizado exitosamente.';
            // Refrescar datos
            $p['nombre'] = $nombre; $p['descripcion'] = $descripcion; $p['precio'] = $precio;
            $p['categoria'] = $categoria; $p['badge'] = $badge; $p['imagen'] = $imagenNombre;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <?php 
  require_once __DIR__ . '/../config/config.php';
  $pageTitle = 'Editar Producto · ' . SITE_NAME; 
  include __DIR__ . '/../includes/head.php'; 
  ?>
  <style>
    body { margin: 0; overflow: hidden; background: var(--color-surface-muted); }
    .admin-layout { display: grid; grid-template-columns: 280px 1fr; height: 100vh; }
    .admin-sidebar { background: var(--color-primary); color: #fff; padding: 2rem 1.5rem; display: flex; flex-direction: column; height: 100%; overflow-y: auto; }
    .admin-nav-link { display: flex; align-items: center; gap: 0.75rem; padding: 1rem; color: var(--color-primary-glow); text-decoration: none; font-size: 0.9rem; font-weight: 500; transition: all 0.3s; border-radius: 4px; }
    .admin-nav-link:hover, .admin-nav-link.active { background: rgba(255,255,255,0.1); color: #fff; }
    .admin-content { padding: 3rem; height: 100vh; overflow-y: auto; }
    .form-group { margin-bottom: 1.5rem; }
    .form-group label { display: block; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft); margin-bottom: 0.5rem; }
    .form-control { width: 100%; padding: 1rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; font-family: var(--font-body); font-size: 0.95rem; }
  </style>
</head>
<body>
  <div class="admin-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>

    <main class="admin-content">
      <header style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 3rem;">
        <div>
          <span class="eyebrow">Catálogo</span>
          <h1 style="font-family: var(--font-display); font-size: 2.5rem; color: var(--color-primary); margin: 0.5rem 0;">Editar Producto</h1>
        </div>
        <a href="productos.php" class="btn btn--ghost" style="border-color: var(--color-line-strong); padding: 0.75rem 1.5rem;">Volver a la lista</a>
      </header>

      <?php if ($error): ?><div style="background: #ffdad6; color: #93000a; padding: 1rem; margin-bottom: 2rem;"><?= $error ?></div><?php endif; ?>
      <?php if ($success): ?><div style="background: #d1e7dd; color: #0f5132; padding: 1rem; margin-bottom: 2rem;"><?= $success ?></div><?php endif; ?>

      <div style="background: #fff; border: 1px solid var(--color-line); padding: 3rem; max-width: 800px;">
        <form method="POST" action="" enctype="multipart/form-data">
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
            <div class="form-group">
              <label>Nombre del Producto *</label>
              <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($p['nombre']) ?>" required>
            </div>
            <div class="form-group">
              <label>Precio (Bs.) *</label>
              <input type="number" step="0.01" name="precio" class="form-control" value="<?= htmlspecialchars($p['precio']) ?>" required>
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
            <div class="form-group">
              <label>Catálogo / Categoría *</label>
              <select name="categoria" class="form-control" required>
                <option value="tradicionales" <?= $p['categoria'] == 'tradicionales' ? 'selected' : '' ?>>Tradicionales</option>
                <option value="frutas" <?= $p['categoria'] == 'frutas' ? 'selected' : '' ?>>Frutas Chiquitanas</option>
                <option value="temporada" <?= $p['categoria'] == 'temporada' ? 'selected' : '' ?>>Ediciones de Temporada</option>
                <option value="helados" <?= $p['categoria'] == 'helados' ? 'selected' : '' ?>>Helados & Copas</option>
                <option value="combos" <?= $p['categoria'] == 'combos' ? 'selected' : '' ?>>Combos & Paquetes</option>
                <option value="veganas" <?= $p['categoria'] == 'veganas' ? 'selected' : '' ?>>Veganas</option>
              </select>
            </div>
            <div class="form-group">
              <label>Etiqueta / Badge (Opcional)</label>
              <input type="text" name="badge" class="form-control" value="<?= htmlspecialchars($p['badge'] ?? '') ?>">
            </div>
          </div>

          <div class="form-group">
            <label>Descripción *</label>
            <textarea name="descripcion" rows="4" class="form-control" required><?= htmlspecialchars($p['descripcion']) ?></textarea>
          </div>

          <div class="form-group" style="background: var(--color-surface-muted); padding: 1.5rem; border: 1px solid var(--color-line);">
            <label>Imagen Actual</label>
            <img src="../assets/uploads/<?= htmlspecialchars($p['imagen']) ?>" alt="Imagen actual" style="height: 100px; margin-bottom: 1rem; display: block;">
            
            <label>Reemplazar Imagen (Opcional)</label>
            <input type="file" name="imagen" class="form-control" accept="image/*">
          </div>

          <button type="submit" class="btn" style="background: var(--color-primary); color: #fff; border: none; padding: 1.2rem 3rem; margin-top: 1rem;">Actualizar Producto</button>
        </form>
      </div>
    </main>
  </div>
</body>
</html>
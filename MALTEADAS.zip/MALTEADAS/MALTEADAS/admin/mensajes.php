<?php
require_once __DIR__ . '/../config/auth.php';
if (!isLoggedIn()) { header("Location: ../login.php"); exit; }

require_once __DIR__ . '/../config/database.php';

// Obtener todos los mensajes
$stmt = $pdo->query("SELECT * FROM mensajes ORDER BY created_at DESC");
$mensajes = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <?php 
  require_once __DIR__ . '/../config/config.php';
  $pageTitle = 'Mensajes · ' . SITE_NAME; 
  include __DIR__ . '/../includes/head.php'; 
  ?>
  <style>
    body { margin: 0; overflow: hidden; background: var(--color-surface-muted); }
    .admin-layout { display: grid; grid-template-columns: 280px 1fr; height: 100vh; }
    .admin-sidebar { background: var(--color-primary); color: #fff; padding: 2rem 1.5rem; display: flex; flex-direction: column; height: 100%; overflow-y: auto; }
    .admin-nav-link { display: flex; align-items: center; gap: 0.75rem; padding: 1rem; color: var(--color-primary-glow); text-decoration: none; font-size: 0.9rem; font-weight: 500; transition: all 0.3s; border-radius: 4px; }
    .admin-nav-link:hover, .admin-nav-link.active { background: rgba(255,255,255,0.1); color: #fff; }
    .admin-content { padding: 3rem; height: 100vh; overflow-y: auto; }

    /* Diseño Premium de Tarjeta de Mensaje */
    .msg-card { 
      background: #fff; 
      border: 1px solid var(--color-line); 
      border-radius: 8px;
      padding: 2rem; 
      margin-bottom: 1.5rem; 
      display: flex; 
      justify-content: space-between;
      gap: 2rem; 
      box-shadow: 0 10px 30px -10px rgba(0,0,0,0.03);
      transition: transform 0.3s, box-shadow 0.3s;
      position: relative;
      overflow: hidden;
    }
    .msg-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 40px -10px rgba(0,0,0,0.08);
    }

    /* Línea lateral de color según el motivo */
    .msg-card::before {
      content: '';
      position: absolute;
      left: 0; top: 0; bottom: 0;
      width: 4px;
      background: var(--color-primary);
    }
    .msg-card.tipo-consulta::before { background: #3b82f6; } /* Azul */
    .msg-card.tipo-mala::before { background: #ef4444; } /* Rojo */
    .msg-card.tipo-felicitacion::before { background: #10b981; } /* Verde */
    .msg-card.tipo-sugerencia::before { background: var(--color-secondary); } /* Dorado */

    .msg-main { flex: 1; }
    
    .msg-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem; }
    .msg-name { font-family: var(--font-display); font-size: 1.6rem; color: var(--color-primary); margin: 0; }
    .msg-date { font-size: 0.75rem; color: var(--color-ink-soft); background: var(--color-surface-muted); padding: 0.25rem 0.75rem; border-radius: 50px; }
    
    .msg-contact-info { display: flex; gap: 1rem; margin-bottom: 1.5rem; font-size: 0.85rem; color: var(--color-ink-soft); }
    .msg-contact-info span { display: flex; align-items: center; gap: 0.35rem; }
    .msg-contact-info .material-symbols-outlined { font-size: 1rem; color: var(--color-secondary); }

    .msg-badge { display: inline-block; padding: 0.35rem 0.75rem; font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; border-radius: 4px; margin-bottom: 0.75rem; }
    .badge-consulta { background: #eff6ff; color: #1d4ed8; }
    .badge-mala { background: #fef2f2; color: #b91c1c; }
    .badge-felicitacion { background: #ecfdf5; color: #047857; }
    .badge-sugerencia { background: #fffbeb; color: #b45309; }

    .msg-text { font-size: 1rem; color: var(--color-ink); line-height: 1.7; padding: 1.5rem; background: var(--color-surface-muted); border-radius: 8px; border-left: 2px solid var(--color-line-strong); }

    .msg-actions { display: flex; flex-direction: column; gap: 0.75rem; justify-content: center; min-width: 160px; }
    
    .btn-action { display: inline-flex; align-items: center; justify-content: center; gap: 0.5rem; padding: 0.85rem 1rem; border-radius: 6px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; text-decoration: none; transition: all 0.2s; width: 100%; border: 1px solid transparent; }
    
    .btn-wa { background: #25d366; color: #fff; box-shadow: 0 4px 10px rgba(37, 211, 102, 0.3); }
    .btn-wa:hover { background: #1ebe5b; transform: translateY(-2px); }
    
    .btn-del { background: transparent; color: #ba1a1a; border-color: #ffdad6; }
    .btn-del:hover { background: #ffdad6; }
  </style>
</head>
<body>
  <div class="admin-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>

    <main class="admin-content">
      <header style="margin-bottom: 3rem; display: flex; justify-content: space-between; align-items: flex-end;">
        <div>
          <span class="eyebrow">Buzón de Entrada</span>
          <h1 style="font-family: var(--font-display); font-size: 2.5rem; color: var(--color-primary); margin: 0.5rem 0;">Mensajes de Clientes</h1>
          <p style="color: var(--color-ink-soft);">Gestiona las consultas, quejas y sugerencias de la web.</p>
        </div>
        <div style="background: #fff; padding: 0.75rem 1.5rem; border-radius: 50px; border: 1px solid var(--color-line); display: flex; align-items: center; gap: 0.5rem;">
          <span class="material-symbols-outlined" style="color: var(--color-secondary);">inbox</span>
          <span style="font-size: 0.85rem; font-weight: 600; color: var(--color-primary);"><?= count($mensajes) ?> mensajes en total</span>
        </div>
      </header>

      <?php if (empty($mensajes)): ?>
        <div style="background: #fff; padding: 5rem; text-align: center; border: 1px dashed var(--color-line-strong); border-radius: 12px;">
          <span class="material-symbols-outlined" style="font-size: 4rem; color: var(--color-line-strong); margin-bottom: 1rem;">mark_email_read</span>
          <h2 style="font-family: var(--font-display); font-size: 1.8rem; color: var(--color-primary);">Todo al día</h2>
          <p style="color: var(--color-ink-soft);">No tienes mensajes nuevos pendientes por responder.</p>
        </div>
      <?php else: ?>
        <?php foreach ($mensajes as $m): ?>
          
          <?php 
            // Determinar clase de color según el motivo
            $motivoClass = 'tipo-consulta';
            $badgeClass = 'badge-consulta';
            if (stripos($m['motivo'], 'mala') !== false) { $motivoClass = 'tipo-mala'; $badgeClass = 'badge-mala'; }
            elseif (stripos($m['motivo'], 'felicit') !== false) { $motivoClass = 'tipo-felicitacion'; $badgeClass = 'badge-felicitacion'; }
            elseif (stripos($m['motivo'], 'sugerencia') !== false) { $motivoClass = 'tipo-sugerencia'; $badgeClass = 'badge-sugerencia'; }
          ?>

          <div class="msg-card <?= $motivoClass ?>">
            <div class="msg-main">
              <div class="msg-header">
                <div>
                  <span class="msg-badge <?= $badgeClass ?>"><?= htmlspecialchars($m['motivo']) ?></span>
                  <h3 class="msg-name"><?= htmlspecialchars($m['nombre']) ?></h3>
                </div>
                <span class="msg-date"><?= date('d M, Y - H:i', strtotime($m['created_at'])) ?></span>
              </div>
              
              <div class="msg-contact-info">
                <span><span class="material-symbols-outlined">mail</span> <?= htmlspecialchars($m['email']) ?></span>
                <?php if (!empty($m['telefono'])): ?>
                  <span><span class="material-symbols-outlined">call</span> <?= htmlspecialchars($m['telefono']) ?></span>
                <?php endif; ?>
              </div>

              <div class="msg-text">
                <?= nl2br(htmlspecialchars($m['mensaje'])) ?>
              </div>
            </div>
            
            <div class="msg-actions">
              <?php if (!empty($m['telefono'])): ?>
                <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $m['telefono']) ?>?text=Hola%20<?= urlencode($m['nombre']) ?>,%20le%20escribimos%20de%20Helader%C3%ADa%20Curupau%20por%20su%20consulta." target="_blank" class="btn-action btn-wa">
                  <span class="material-symbols-outlined" style="font-size: 1.2rem;">chat</span> WhatsApp
                </a>
              <?php endif; ?>
              <a href="mensajes_eliminar.php?id=<?= $m['id'] ?>" class="btn-action btn-del" onclick="return confirm('¿Estás seguro de eliminar este mensaje permanentemente?');">
                <span class="material-symbols-outlined" style="font-size: 1.2rem;">delete</span> Eliminar
              </a>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </main>
  </div>
</body>
</html>
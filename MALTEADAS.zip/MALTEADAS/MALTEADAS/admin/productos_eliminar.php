<?php
require_once __DIR__ . '/../config/auth.php';
if (!isLoggedIn()) { header("Location: ../login.php"); exit; }

require_once __DIR__ . '/../config/database.php';

$id = $_GET['id'] ?? null;
if ($id) {
    // Obtener el nombre de la imagen para borrarla
    $stmt = $pdo->prepare("SELECT imagen FROM productos WHERE id = ?");
    $stmt->execute([$id]);
    $producto = $stmt->fetch();
    
    if ($producto) {
        // Borrar el archivo físico
        $filePath = __DIR__ . '/../assets/uploads/' . $producto['imagen'];
        if (file_exists($filePath)) { unlink($filePath); }
        
        // Borrar de la BD
        $stmt = $pdo->prepare("DELETE FROM productos WHERE id = ?");
        $stmt->execute([$id]);
    }
}

header("Location: productos.php");
exit;
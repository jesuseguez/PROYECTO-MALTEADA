<?php
require_once __DIR__ . '/../config/auth.php';
if (!isLoggedIn()) { header("Location: ../login.php"); exit; }

require_once __DIR__ . '/../config/database.php';

// 1. Contar Productos
$stmt = $pdo->query("SELECT COUNT(*) as total FROM productos");
$totalProductos = $stmt->fetch()['total'];

// 2. Contar Mensajes Nuevos (Reales)
$stmt = $pdo->query("SELECT COUNT(*) as total FROM mensajes");
$totalMensajes = $stmt->fetch()['total'];

// 3. Contar Clics en WhatsApp
$stmt = $pdo->query("SELECT COUNT(*) as total FROM clicks_whatsapp");
$totalWhatsApp = $stmt->fetch()['total'];

// 4. Contar Visitas Totales
$stmt = $pdo->query("SELECT COUNT(*) as total FROM visitas");
$totalVisitas = $stmt->fetch()['total'];

// 5. Datos para el gráfico (Últimos 7 días)
$chartLabels = [];
$chartData = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chartLabels[] = date('d M', strtotime("-$i days"));
    
    // Contar visitas en esa fecha
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM visitas WHERE fecha = ?");
    $stmt->execute([$date]);
    $chartData[] = $stmt->fetch()['total'];
}

$stmtUltimosMensajes = $pdo->query("SELECT * FROM mensajes ORDER BY created_at DESC LIMIT 3");
$ultimosMensajes = $stmtUltimosMensajes->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <?php 
  require_once __DIR__ . '/../config/config.php';
  $pageTitle = 'Dashboard · ' . SITE_NAME; 
  include __DIR__ . '/../includes/head.php'; 
  ?>
  <!-- Librería para el gráfico -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
  <style>
    body { margin: 0; overflow: hidden; background: var(--color-surface-muted); }
    .admin-layout { display: grid; grid-template-columns: 280px 1fr; height: 100vh; }
    .admin-sidebar { background: var(--color-primary); color: #fff; padding: 2rem 1.5rem; display: flex; flex-direction: column; height: 100%; overflow-y: auto; }
    .admin-nav-link { display: flex; align-items: center; gap: 0.75rem; padding: 1rem; color: var(--color-primary-glow); text-decoration: none; font-size: 0.9rem; font-weight: 500; transition: all 0.3s; border-radius: 4px; }
    .admin-nav-link:hover, .admin-nav-link.active { background: rgba(255,255,255,0.1); color: #fff; }
    .admin-content { padding: 3rem; height: 100vh; overflow-y: auto; }

    .card { background: #fff; padding: 2rem; border: 1px solid var(--color-line); border-radius: 8px; box-shadow: 0 10px 30px -10px rgba(0,0,0,0.03); }
    
    .stat-value { font-family: var(--font-display); font-size: 3rem; color: var(--color-primary); line-height: 1; margin-top: 1rem; }
    .stat-icon { font-size: 2.5rem; color: var(--color-secondary); }
  </style>
</head>
<body>

  <div class="admin-layout">
    <!-- Importamos el sidebar -->
    <?php include __DIR__ . '/sidebar.php'; ?>

    <main class="admin-content">
      
      <header style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 3rem;">
        <div>
          <span class="eyebrow">Panel de Control</span>
          <h1 style="font-family: var(--font-display); font-size: 2.5rem; color: var(--color-primary); margin: 0.5rem 0;">
            Dashboard
          </h1>
          <p style="color: var(--color-ink-soft); font-size: 0.95rem;">Bienvenido a tu centro de mando, <?= htmlspecialchars($_SESSION['user_name']) ?>.</p>
        </div>
        <a href="../index.php" class="btn btn--ghost" style="border-color: var(--color-line-strong); padding: 0.75rem 1.5rem;">
          <span class="material-symbols-outlined">open_in_new</span> Ver la web
        </a>
      </header>

      <!-- Tarjetas de Estadísticas -->
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; margin-bottom: 2rem;">
        
        <div class="card">
          <div style="display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
              <span style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft);">Productos Activos</span>
              <div class="stat-value"><?= $totalProductos ?></div>
            </div>
            <span class="material-symbols-outlined stat-icon">icecream</span>
          </div>
        </div>

        <div class="card">
          <div style="display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
              <span style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft);">Mensajes Recibidos</span>
              <div class="stat-value"><?= $totalMensajes ?></div>
            </div>
            <span class="material-symbols-outlined stat-icon">mail</span>
          </div>
        </div>

        <div class="card">
          <div style="display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
              <span style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft);">Clics WhatsApp</span>
              <div class="stat-value"><?= $totalWhatsApp ?></div>
            </div>
            <span class="material-symbols-outlined stat-icon" style="color: #25d366;">chat</span>
          </div>
        </div>

        <div class="card">
          <div style="display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
              <span style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft);">Visitas Totales</span>
              <div class="stat-value"><?= $totalVisitas ?></div>
            </div>
            <span class="material-symbols-outlined stat-icon">visibility</span>
          </div>
        </div>

      </div>

      <!-- Gráfico y Mensajes -->
      <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
        
        <!-- Gráfico de Visitas -->
        <div class="card">
          <h3 style="font-family: var(--font-display); font-size: 1.5rem; color: var(--color-primary); margin-bottom: 2rem;">Visitas de los últimos 7 días</h3>
          <canvas id="visitsChart" height="100"></canvas>
        </div>

        <!-- Últimos Mensajes -->
        <div class="card">
          <h3 style="font-family: var(--font-display); font-size: 1.5rem; color: var(--color-primary); margin-bottom: 1.5rem; display: flex; justify-content: space-between;">
            Bandeja de entrada
            <a href="mensajes.php" style="font-size: 0.8rem; color: var(--color-secondary); text-decoration: none; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; margin-top: auto;">Ver todos</a>
          </h3>
          
          <div style="display: flex; flex-direction: column; gap: 1rem;">
            <?php if (empty($ultimosMensajes)): ?>
              <p style="color: var(--color-ink-soft); font-size: 0.9rem;">No hay mensajes recientes.</p>
            <?php else: ?>
              <?php foreach ($ultimosMensajes as $m): ?>
                <div style="border-bottom: 1px solid var(--color-surface-muted); padding-bottom: 1rem;">
                  <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                    <strong style="font-size: 0.9rem; color: var(--color-primary);"><?= htmlspecialchars($m['nombre']) ?></strong>
                    <span style="font-size: 0.7rem; color: var(--color-ink-soft);"><?= date('d M', strtotime($m['created_at'])) ?></span>
                  </div>
                  <span style="font-size: 0.75rem; color: var(--color-secondary); font-weight: 700;"><?= htmlspecialchars($m['motivo']) ?></span>
                  <p style="font-size: 0.85rem; color: var(--color-ink-soft); margin-top: 0.5rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?= htmlspecialchars($m['mensaje']) ?></p>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>

      </div>

    </main>
  </div>

  <script>
    // Configuración del Gráfico elegante (Estilo Lujo)
    const ctx = document.getElementById('visitsChart').getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: <?= json_encode($chartLabels) ?>,
        datasets: [{
          label: 'Visitas',
          data: <?= json_encode($chartData) ?>,
          borderColor: '#c8a97e', /* Color Dorado */
          backgroundColor: 'rgba(200, 169, 126, 0.1)',
          borderWidth: 2,
          pointBackgroundColor: '#1c1c1a',
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 4,
          tension: 0.4, /* Curva suave */
          fill: true
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(0,0,0,0.05)' },
            ticks: { stepSize: 1, color: '#6b6b65' }
          },
          x: {
            grid: { display: false },
            ticks: { color: '#6b6b65' }
          }
        }
      }
    });
  </script>
</body>
</html>
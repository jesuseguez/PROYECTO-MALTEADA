<?php
/**
 * Heladería Curupau — Configuración Global
 * by Jesus Eguez
 */

declare(strict_types=1);

// Iniciar sesión solo si no está activa (Evita el error Notice)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================
// METADATOS DEL SITIO
// ============================================
define('SITE_NAME', 'Heladería Curupau');
define('SITE_TAGLINE', 'San José de Chiquitos');
define('SITE_DESCRIPTION', 'Malteadas artesanales de yuca y helados premium en el corazón de la Chiquitania.');
define('SITE_AUTHOR', 'Jesus Eguez');
define('SITE_YEAR', date('Y'));

// ============================================
// CONTACTO
// ============================================
define('WHATSAPP_NUMBER', '59173684406');
define('WHATSAPP_URL', 'https://wa.me/' . WHATSAPP_NUMBER);
define('PHONE_FIJO', '+591 (3) 972-2045');
define('EMAIL_CONTACT', 'hola@curupau-chiquitos.bo');
define('ADDRESS', 'Calle Ñuflo de Chávez, San José de Chiquitos, Santa Cruz — Bolivia');

// ============================================
// RUTAS
// ============================================
define('BASE_URL', '/');
define('ASSETS', BASE_URL . 'assets/');

// ============================================
// PÁGINA ACTUAL
// ============================================
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$currentPage = $currentPage === 'index' ? 'inicio' : $currentPage;

// ============================================
// HELPERS
// ============================================
function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function is_active(string $page, string $current): string {
    return $page === $current ? 'is-active' : '';
}

function asset(string $path): string {
    return ASSETS . ltrim($path, '/');
}

function whatsapp_link(string $message = ''): string {
    $base = WHATSAPP_URL;
    return $message ? $base . '?text=' . urlencode($message) : $base;
}
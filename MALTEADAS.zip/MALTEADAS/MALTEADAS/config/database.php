<?php
/**
 * Conexión a Base de Datos MySQL
 * by Jesus Eguez
 */
$host = 'localhost';
$dbname = 'curupau_db';
$username = 'root'; // Usuario por defecto de XAMPP/WAMP
$password = ''; // Contraseña por defecto (déjalo vacío si usas XAMPP)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error de conexión a la base de datos: " . $e->getMessage());
}
?>
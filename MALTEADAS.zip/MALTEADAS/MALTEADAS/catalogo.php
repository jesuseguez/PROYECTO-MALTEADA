<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php'; // Conexión a la BD

$pageTitle = 'Catálogo de Malteadas · ' . SITE_NAME;

// 1. Consulta SQL para traer todos los productos
$stmt = $pdo->query("SELECT * FROM productos ORDER BY id DESC");
$productosDB = $stmt->fetchAll();

// 2. Agrupamos los productos por categoría
$products = [];
foreach ($productosDB as $p) {
    $products[$p['categoria']][] = [
        'id' => $p['id'],
        'name' => $p['nombre'],
        'desc' => $p['descripcion'],
        'price' => $p['precio'],
        'img' => 'assets/uploads/' . $p['imagen'],
        'badge' => $p['badge']
    ];
}

$categories = [
    'todas' => 'Todas',
    'tradicionales' => 'Tradicionales',
    'frutas' => 'Frutas Chiquitanas',
    'temporada' => 'Temporada',
    'helados' => 'Helados & Copas',
    'combos' => 'Combos',
    'veganas' => 'Veganas',
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <?php include __DIR__ . '/includes/head.php'; ?>
</head>
<body style="background-color: var(--color-surface-muted); margin: 0;">

  <?php include __DIR__ . '/includes/header.php'; ?>

  <main class="page-main" style="padding-top: calc(var(--header-height) + 2rem);">
    
    <!-- HERO CATÁLOGO -->
    <section style="padding: 4rem 0 3rem; text-align: center;">
      <div class="container">
        <span class="eyebrow">Catálogo · Carta Completa</span>
        <h1 style="font-family: var(--font-display); font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 400; color: var(--color-primary); margin: 1rem 0;">
          Catálogo de <em style="color: var(--color-secondary);">Malteadas</em> & Helados
        </h1>
        <p style="color: var(--color-ink-soft); font-size: 1.1rem; max-width: 600px; margin: 0 auto 3rem;">
          Nuestra célebre emulsión de yuca cocida con leche fresca de estancia, frutas nativas del bosque seco chiquitano y especias jesuíticas. 100% libre de gluten.
        </p>
      </div>
    </section>

    <!-- FILTROS STICKY Y BUSCADOR -->
    <section id="filtros-seccion" style="position: sticky; top: var(--header-height); z-index: 40; background: var(--color-surface); border-bottom: 1px solid var(--color-line); padding: 1.5rem 0; box-shadow: 0 10px 20px -10px rgba(0,0,0,0.05);">
      <div class="container">
        <div style="display: flex; flex-direction: column; gap: 1.5rem; align-items: center;">
          
          <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 0.75rem; width: 100%;">
            <?php foreach ($categories as $key => $label): ?>
              <button class="filter-pill <?= $key === 'todas' ? 'active' : '' ?>" 
                      id="pill-<?= e($key) ?>"
                      data-category="<?= e($key) ?>" 
                      onclick="filterCategory(this, '<?= e($key) ?>')">
                <?= e($label) ?>
              </button>
            <?php endforeach; ?>
          </div>

          <div style="position: relative; width: 100%; max-width: 500px;">
            <span class="material-symbols-outlined" style="position: absolute; left: 1rem; top: 50%; transform: translateY(-50%); color: var(--color-ink-soft);">search</span>
            <input type="text" id="catalogSearch" placeholder="Buscar ingrediente o malteada..." oninput="searchProducts()"
                   style="width: 100%; padding: 1rem 1rem 1rem 3rem; font-family: var(--font-body); font-size: 0.9rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; transition: all 0.3s;">
          </div>

        </div>
      </div>
    </section>

    <!-- GRID DE PRODUCTOS -->
    <section style="padding: 5rem 0;">
      <div class="container">
        
        <div id="catalogGrid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 320px)); gap: 4rem; justify-content: center;">
          
          <?php if (!empty($products)): ?>
            <?php foreach ($products as $category => $items): ?>
              <?php foreach ($items as $p): ?>
                
                <article class="product-card" style="display: flex; flex-direction: column; align-items: center; text-align: center;" data-category="<?= e($category) ?>" data-name="<?= e(strtolower($p['name'] . ' ' . $p['desc'])) ?>">
                  
                  <!-- NUEVA IMAGEN TIPO RETRATO / CUADRADO PREMIUM -->
                  <div style="width: 100%; max-width: 320px; aspect-ratio: 4/5; margin: 0 auto 1.5rem; overflow: hidden; border-radius: 12px; position: relative; background: var(--color-surface-muted); border: 1px solid var(--color-line); box-shadow: 0 10px 20px -10px rgba(0,0,0,0.1);">
                    <img src="<?= e($p['img']) ?>" alt="<?= e($p['name']) ?>" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.7s ease;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                  </div>

                  <!-- Etiqueta centrada debajo de la foto -->
                  <?php if (!empty($p['badge'])): ?>
                    <span style="background: var(--color-secondary); color: var(--color-primary); font-size: 0.65rem; font-weight: 700; padding: 0.4rem 1.2rem; text-transform: uppercase; letter-spacing: 0.15em; border-radius: 50px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); margin-bottom: 1rem; display: inline-block;">
                      <?= e($p['badge']) ?>
                    </span>
                  <?php endif; ?>

                  <div style="width: 100%;">
                    <h3 style="font-family: var(--font-display); font-size: 1.8rem; font-weight: 400; color: var(--color-primary); margin-bottom: 0.5rem;"><?= e($p['name']) ?></h3>
                    
                    <div style="display: flex; align-items: center; justify-content: center; gap: 0.5rem; margin-bottom: 1rem;">
                      <span style="width: 20px; height: 1px; background: var(--color-secondary);"></span>
                      <span style="font-family: var(--font-body); font-size: 0.9rem; font-weight: 600; color: var(--color-secondary);"><?= $p['price'] ?> Bs.</span>
                      <span style="width: 20px; height: 1px; background: var(--color-secondary);"></span>
                    </div>
                    
                    <p style="font-size: 0.95rem; color: var(--color-ink-soft); line-height: 1.6; font-weight: 300; margin-bottom: 1.5rem;">
                      <?= e($p['desc']) ?>
                    </p>
                    
                    <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>?text=Hola,%20quiero%20pedir%20<?= urlencode($p['name']) ?>" target="_blank"
                       style="display: inline-flex; align-items: center; gap: 0.5rem; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-primary); border-bottom: 1px solid var(--color-primary); padding-bottom: 0.2rem; transition: all 0.3s;"
                       onmouseover="this.style.color='var(--color-secondary)'; this.style.borderColor='var(--color-secondary)'"
                       onmouseout="this.style.color='var(--color-primary)'; this.style.borderColor='var(--color-primary)'">
                      Pedir ahora
                    </a>
                  </div>
                </article>

              <?php endforeach; ?>
            <?php endforeach; ?>
          <?php else: ?>
            <p style="text-align: center; grid-column: 1 / -1; color: var(--color-ink-soft);">Aún no hay productos registrados en la base de datos.</p>
          <?php endif; ?>
        </div>
        
        <p id="noResults" style="display: none; text-align: center; padding: 4rem 0; color: var(--color-ink-soft); font-size: 1.1rem;">
          No encontramos productos con ese criterio.
        </p>
      </div>
    </section>

  </main>

  <?php include __DIR__ . '/includes/footer.php'; ?>

  <!-- Script de Filtros y Scroll Automático -->
  <script>
    let activeCategory = 'todas';
    let searchQuery = '';

    function filterCategory(btn, category) {
      document.querySelectorAll('.filter-pill').forEach(b => b.classList.remove('active'));
      
      if (btn) {
        btn.classList.add('active');
      } else {
        const targetBtn = document.getElementById('pill-' + category);
        if (targetBtn) targetBtn.classList.add('active');
      }
      
      activeCategory = category;
      applyFilters();
    }

    function searchProducts() {
      searchQuery = document.getElementById('catalogSearch').value.toLowerCase().trim();
      applyFilters();
    }

    function applyFilters() {
      const cards = document.querySelectorAll('.product-card');
      let visibleCount = 0;

      cards.forEach(card => {
        const catMatch = activeCategory === 'todas' || card.dataset.category === activeCategory;
        const textMatch = card.dataset.name.includes(searchQuery);
        
        if (catMatch && textMatch) {
          card.style.display = 'flex';
          visibleCount++;
        } else {
          card.style.display = 'none';
        }
      });

      document.getElementById('noResults').style.display = visibleCount === 0 ? 'block' : 'none';
    }

    function handleHashChange() {
      const hash = window.location.hash.replace('#', '');
      
      if (hash && ['tradicionales', 'frutas', 'temporada', 'helados', 'combos', 'veganas'].includes(hash)) {
        filterCategory(null, hash);
        
        const targetBtn = document.getElementById('pill-' + hash);
        if (targetBtn) {
            targetBtn.classList.add('highlight');
            setTimeout(() => targetBtn.classList.remove('highlight'), 2000);
        }

        setTimeout(() => {
          const filtrosSection = document.getElementById('filtros-seccion');
          if(filtrosSection) {
            const y = filtrosSection.getBoundingClientRect().top + window.scrollY - 100;
            window.scrollTo({top: y, behavior: 'smooth'});
          }
        }, 150);
      }
    }

    document.addEventListener("DOMContentLoaded", handleHashChange);
    window.addEventListener("hashchange", handleHashChange);
  </script>
</body>
</html>
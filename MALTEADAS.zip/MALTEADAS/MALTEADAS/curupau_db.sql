-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-10-2026 a las 23:31:55
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `curupau_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clicks_whatsapp`
--

CREATE TABLE `clicks_whatsapp` (
  `id` int(11) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `clicks_whatsapp`
--

INSERT INTO `clicks_whatsapp` (`id`, `fecha`) VALUES
(1, '2026-10-28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `motivo` varchar(100) NOT NULL,
  `mensaje` text NOT NULL,
  `telefono` varchar(50) DEFAULT NULL,
  `leido` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `badge` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio`, `categoria`, `imagen`, `badge`, `created_at`) VALUES
(2, 'Malteada Clásica de Yuca', 'La receta fundacional. Yuca criolla cocida a fuego lento, leche entera de estancia, canela de Ceilán y un sutil toque de clavo de olor.', 22.00, 'tradicionales', 'malteada_yuca.jpg', 'La Original', '2026-10-30 01:50:25'),
(3, 'Yuca & Coco Tostado', 'Yuca infusionada con coco rallado dorado en horno de barro chiquitano y leche condensada artesanal de vaquería local.', 25.00, 'tradicionales', 'yuca_coco.jpg', 'Favorita', '2026-10-30 01:50:25'),
(4, 'Yuca Chévere & Dulce de Leche', 'Yuca batida con dulce de leche casero, cocinado a fuego lento en paila de cobre durante 6 horas. Textura de caramelo lácteo.', 26.00, 'tradicionales', 'yuca_dulce.jpg', 'Receta Colonial', '2026-10-30 01:50:25'),
(5, 'Yuca & Café Misionero', 'Café arábica de las misiones jesuíticas, macerado con vainilla silvestre y emulsionado en frío con nuestra base de yuca.', 25.00, 'tradicionales', 'yuca_cafe.jpg', '', '2026-10-30 01:50:25'),
(6, 'Yuca & Maracuyá Silvestre', 'El contraste perfecto. La cremosidad densa de la yuca con la acidez vivaz y perfumada de la fruta de la pasión del bosque seco.', 26.00, 'frutas', 'default.jpg', 'Refrescante', '2026-10-30 01:50:25'),
(7, 'Yuca & Copoazú de la Selva', 'El teobroma chiquitano. Una emulsión súper cremosa con notas florales entre piña y maracuyá silvestre.', 28.00, 'frutas', 'default.jpg', 'Exótica Nativa', '2026-10-30 01:50:25'),
(8, 'Yuca & Achachairú / Guapurú', 'Joya del monte cruceño. Pulpa fresca de achachairú agridulce fusionada con reducción de néctar de guapurú silvestre.', 28.00, 'frutas', 'default.jpg', 'Edición Limitada', '2026-10-30 01:50:25'),
(9, 'Copa Suprema San José', 'Base de bizcocho chiquitano bañado en licor de caña, 2 bolas de helado de yuca y coco, reducción de guapurú y chipilos acaramelados.', 32.00, 'helados', 'default.jpg', 'Especialidad', '2026-10-30 01:50:25'),
(10, 'Sundae de Yuca & Caramelo Salado', 'Bola de helado de yuca bañada con toffee de azúcar de caña tostada y sal marina de San José.', 28.00, 'helados', 'default.jpg', 'Fusión', '2026-10-30 01:50:25'),
(11, 'Helado Artesanal de Yuca (1/2 Litro)', 'Para llevar a casa. Nuestro clásico helado de yuca con canela en un envase ecológico y térmico.', 45.00, 'helados', 'default.jpg', 'Para Llevar', '2026-10-30 01:50:25'),
(12, 'Cuñapé Chiquitano (x6)', 'Panecillos de almidón de yuca y queso fresco, horneados al momento en horno de barro. Textura esponjosa por dentro y crujiente por fuera.', 15.00, 'combos', 'default.jpg', 'Recién Horneado', '2026-10-30 01:50:25'),
(13, 'Chipilos de Yuca con Miel', 'Aros de yuca fritos y crujientes, bañados en miel pura de caña de trapiche local.', 12.00, 'combos', 'default.jpg', 'Tradicional', '2026-10-30 01:50:25'),
(14, 'Bizcocho de Arroz y Yuca', 'Bizcocho húmedo tradicional de la región, perfecto para acompañar el café misionero o una malteada.', 18.00, 'combos', 'default.jpg', NULL, '2026-10-30 01:50:25'),
(15, 'Combo Merienda Josesana', '2 Malteadas clásicas (o de coco) + Canasta con 4 cuñapés recién salidos del horno de barro y chipilos de yuca con miel.', 48.00, 'combos', 'default.jpg', 'Ahorra 10 Bs.', '2026-10-30 01:50:25'),
(16, 'Pack Misionero Degustación', '4 Copas completas a elección + termo ecológico con porciones extras de topping crujiente de coco al horno, chipilos y salsa tibia de caña.', 85.00, 'combos', 'default.jpg', 'Para 4-6 Personas', '2026-10-30 01:50:25'),
(17, 'Yuca, Miel de Caña & Nuez', 'Leche de coco y almendras chiquitanas con base pura de almidón de yuca, endulzada con miel negra de caña pura.', 26.00, 'veganas', 'default.jpg', '100% Vegana', '2026-10-30 01:50:25'),
(18, 'Helado Vegano de Frutas', 'Helado a base de agua y pulpa de frutas nativas, sin lácteos ni azúcar añadido. Puro sabor a selva.', 24.00, 'veganas', 'default.jpg', 'Sin Lácteos', '2026-10-30 01:50:25'),
(19, 'Festiva con Miel Señorita', 'Elaborada con auténtica miel medicinal de abeja nativa Señorita de la serranía chiquitana, especias misioneras secretas y crema espesa de yuca.', 29.00, 'temporada', 'default.jpg', 'Edición Festiva', '2026-10-30 01:50:25'),
(20, 'Malteada de Cacao Criollo', 'Granos de cacao 100% puro de recolección silvestre, molidos a piedra y fundidos en la base tibia de yuca antes de congelar al batido.', 27.00, 'temporada', 'default.jpg', 'Gourmet Intenso', '2026-10-30 01:50:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('admin','cliente') DEFAULT 'cliente',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `usuario`, `password`, `rol`, `created_at`) VALUES
(6, 'Maria Lorena', 'admin', '$2y$10$Rq77lERo1f1BpaAeEzWom.6ESRvynODWAmzI9rSr991VzhrhY8EpW', 'admin', '2026-10-30 01:04:36');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visitas`
--

CREATE TABLE `visitas` (
  `id` int(11) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `visitas`
--

INSERT INTO `visitas` (`id`, `fecha`) VALUES
(3, '2026-10-26'),
(2, '2026-10-27'),
(1, '2026-10-28'),
(6, '2026-10-30');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clicks_whatsapp`
--
ALTER TABLE `clicks_whatsapp`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `fecha` (`fecha`);

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `visitas`
--
ALTER TABLE `visitas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `fecha` (`fecha`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clicks_whatsapp`
--
ALTER TABLE `clicks_whatsapp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `visitas`
--
ALTER TABLE `visitas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

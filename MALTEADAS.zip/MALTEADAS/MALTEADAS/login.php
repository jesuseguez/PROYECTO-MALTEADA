<?php
// Incluimos config primero para evitar conflictos
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/auth.php';

// Si ya está logueado, redirigir a la carpeta admin
if (isLoggedIn()) {
    header("Location: admin/dashboard.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (login($usuario, $password)) {
        header("Location: admin/dashboard.php");
        exit;
    } else {
        $error = 'Usuario o contraseña incorrectos.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <?php 
  $pageTitle = 'Ingresar · ' . SITE_NAME; 
  include __DIR__ . '/includes/head.php'; 
  ?>
</head>
<body style="background-color: var(--color-surface-muted); margin: 0; display: flex; align-items: center; justify-content: center; min-height: 100vh;">

  <div style="width: 100%; max-width: 450px; padding: 3rem; background: var(--color-surface); border: 1px solid var(--color-line); box-shadow: 0 20px 50px -15px rgba(0,0,0,0.1);">
    
    <!-- Logo -->
    <div style="text-align: center; margin-bottom: 3rem;">
      <a href="index.php" style="display: inline-flex; align-items: center; gap: 0.75rem; text-decoration: none;">
        <span style="width: 3rem; height: 3rem; display: flex; align-items: center; justify-content: center; background: var(--color-primary); color: var(--color-secondary);">
          <span class="material-symbols-outlined">icecream</span>
        </span>
        <span style="font-family: var(--font-display); font-size: 2rem; font-weight: 600; color: var(--color-primary);">Curupau</span>
      </a>
      <h1 style="font-family: var(--font-display); font-size: 2rem; font-weight: 400; color: var(--color-primary); margin-top: 1.5rem;">Bienvenido de nuevo</h1>
      <p style="color: var(--color-ink-soft); font-size: 0.9rem; margin-top: 0.5rem;">Ingresa a tu cuenta para continuar.</p>
    </div>

    <!-- Mensaje de Error -->
    <?php if ($error): ?>
      <div style="background: rgba(255, 0, 0, 0.05); border-left: 3px solid #ba1a1a; padding: 1rem; margin-bottom: 2rem; color: #ba1a1a; font-size: 0.85rem;">
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <!-- Formulario -->
    <form method="POST" action="" style="display: flex; flex-direction: column; gap: 1.5rem;">
      <div>
        <label style="display: block; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft); margin-bottom: 0.5rem;">Usuario</label>
        <input type="text" name="usuario" required placeholder="Tu nombre de usuario" style="width: 100%; padding: 1rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; font-family: var(--font-body); font-size: 0.95rem;">
      </div>
      
      <div>
        <label style="display: block; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft); margin-bottom: 0.5rem;">Contraseña</label>
        <input type="password" name="password" required placeholder="••••••••" style="width: 100%; padding: 1rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; font-family: var(--font-body); font-size: 0.95rem;">
      </div>

      <button type="submit" class="btn" style="background: var(--color-primary); color: #fff; border: none; width: 100%; padding: 1.2rem; margin-top: 1rem;">
        Iniciar Sesión
      </button>
    </form>

    <div style="text-align: center; margin-top: 2rem;">
      <a href="index.php" style="font-size: 0.85rem; color: var(--color-ink-soft); text-decoration: underline;">Volver al inicio</a>
    </div>

  </div>

</body>
</html>
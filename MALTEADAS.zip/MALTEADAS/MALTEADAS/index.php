<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php'; // Conexión a la BD

$pageTitle = 'Curupau — Alta Heladería Artesanal';

// ============================================
// REGISTRAR VISITA DIARIA (Estadísticas)
// ============================================
$hoy = date('Y-m-d');
try {
    $stmtVisita = $pdo->prepare("INSERT IGNORE INTO visitas (fecha) VALUES (?)");
    $stmtVisita->execute([$hoy]);
} catch (Exception $e) {
    // Silencioso para no romper la web si falta la tabla
}

// ============================================
// CARGAR PRODUCTOS DESTACADOS
// ============================================
$stmt = $pdo->query("SELECT * FROM productos ORDER BY id DESC LIMIT 3");
$productosDB = $stmt->fetchAll();

// Adaptamos los datos para que el HTML de abajo los use
$featuredProducts = array_map(function($p) {
    return [
        'name' => $p['nombre'],
        'desc' => $p['descripcion'],
        'price' => $p['precio'],
        'img' => 'assets/uploads/' . $p['imagen'],
    ];
}, $productosDB);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <?php include __DIR__ . '/includes/head.php'; ?>
  <style>
    /* Estilos exclusivos para el Slider del Banner */
    .hero-slider {
      position: relative;
      width: 100%;
      height: 70vh;
      min-height: 550px;
      overflow: hidden;
      background: #000;
    }
    .slide {
      position: absolute;
      top: 0; left: 0; width: 100%; height: 100%;
      opacity: 0;
      transition: opacity 1.5s ease-in-out;
      z-index: 1;
    }
    .slide.active { opacity: 1; z-index: 2; }
    
    .slide img {
      width: 100%; height: 100%; object-fit: cover;
      animation: zoomEffect 10s linear forwards; 
    }
    @keyframes zoomEffect {
      from { transform: scale(1); }
      to { transform: scale(1.1); }
    }

    .slide-overlay {
      position: absolute;
      inset: 0;
      background: linear-gradient(to right, rgba(28,28,26,0.85) 0%, rgba(28,28,26,0.3) 100%);
      z-index: 3;
    }

    .slide-content {
      position: absolute;
      top: 50%; left: 0; transform: translateY(-50%);
      width: 100%; z-index: 4;
    }
    
    .slider-dots {
      position: absolute;
      bottom: 2rem; left: 50%; transform: translateX(-50%);
      display: flex; gap: 0.75rem; z-index: 5;
    }
    .dot {
      width: 30px; height: 2px; background: rgba(255,255,255,0.3);
      cursor: pointer; transition: all 0.3s;
    }
    .dot.active { background: var(--color-secondary); }
  </style>
</head>
<body style="background-color: var(--color-surface-muted); margin: 0;">

  <?php include __DIR__ . '/includes/header.php'; ?>

  <main style="padding-top: var(--header-height);">
    
    <!-- BANNER SLIDER PREMIUM -->
    <section class="hero-slider" id="heroSlider">
      
      <div class="slide active">
        <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuAP4w2Mtp7nbCX59ebbSKiFApZxptkkAF8f_ElGi0maO1YemsQfeS8E47BLOFRw2qWgZjqfwFiR-5O19D0YXHeLQNmjp_1sqRLgAvQdyVkJUDshYJd-n_AccXAPikrfhUJzmqyf5ntVI2eQGNvyfUEYq_xOXth7hTIQtsqXWk6nrKLahgbqYmF5bKwsmp7VBya8JDH5UwP0iPg7P7CcxtXCGnSZWGSatUSuulCN8zOFow75de88i6I" alt="Malteada Clásica">
        <div class="slide-overlay"></div>
        <div class="slide-content">
          <div class="container">
            <span class="eyebrow eyebrow--light">San José de Chiquitos</span>
            <h1 style="font-family: var(--font-display); font-size: clamp(3.5rem, 6vw, 6rem); color: #fff; line-height: 1.05; margin-top: 1rem;">
              El arte de la <br> <em style="color: var(--color-secondary);">yuca</em> y el hielo.
            </h1>
            <p style="color: rgba(255,255,255,0.8); font-size: 1.1rem; max-width: 500px; margin-top: 2rem; line-height: 1.8;">
              Una experiencia gastronómica sin precedentes. Elevamos la raíz más noble de la Chiquitania a su máxima expresión artesanal.
            </p>
            <div style="display: flex; gap: 1rem; margin-top: 3rem;">
              <a href="catalogo.php" class="btn" style="background: var(--color-secondary); border: 1px solid var(--color-secondary); color: var(--color-primary);">Explorar Carta</a>
              <a href="<?= whatsapp_link('Hola Curupau') ?>" class="btn btn--ghost" style="border-color: #fff; color: #fff;">Pedir por WhatsApp</a>
            </div>
          </div>
        </div>
      </div>

      <div class="slide">
        <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuD-KXkpr7cGGhPTm7flhatI9qoO5PjecfMeTxy_atTv1gtE7od6_e2aOwbe2iV0z2olvLLXAsGM_hKdts3WfFFRCX1SxMRvbtyQ6uikQ9YpPgkHe4OcxKvyNWgYD4mRtpQu40ysZqTtxjLob9xO2e4e8dnJrhXeiOx0u-LCV5M2aIuvur7jBsVSWdxnvAUlHefz11sXN1ZbjmD5iNHzOa9dVLV0S7WgIqIXNmgSUOMaNCYbwp4MHck" alt="Coco Tostado">
        <div class="slide-overlay"></div>
        <div class="slide-content">
          <div class="container">
            <span class="eyebrow eyebrow--light">Edición de Temporada</span>
            <h2 style="font-family: var(--font-display); font-size: clamp(3rem, 5vw, 5rem); color: #fff; line-height: 1.1; margin-top: 1rem;">
              Cosecha al <br> <em style="color: var(--color-secondary);">amanecer</em>.
            </h2>
            <p style="color: rgba(255,255,255,0.8); font-size: 1.1rem; max-width: 500px; margin-top: 2rem;">
              El auténtico coco tostado en horno de barro, seleccionado por nuestras comunidades locales.
            </p>
          </div>
        </div>
      </div>

      <div class="slider-dots">
        <div class="dot active" onclick="goToSlide(0)"></div>
        <div class="dot" onclick="goToSlide(1)"></div>
      </div>
    </section>

    <!-- SECCIÓN DE PRODUCTOS -->
    <section style="padding: 8rem 0; background-color: var(--color-surface);">
      <div class="container">
        <div style="text-align: center; margin-bottom: 5rem;">
          <span style="font-size: 0.75rem; font-weight: 700; letter-spacing: 0.2em; text-transform: uppercase; color: var(--color-secondary);">La Colección</span>
          <h2 style="font-family: var(--font-display); font-size: 3.5rem; font-weight: 400; color: var(--color-primary); margin-top: 1rem;">Sabores Insignia</h2>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 4rem;">
          <?php if (!empty($featuredProducts)): ?>
            <?php foreach ($featuredProducts as $p): ?>
              <article style="display: flex; flex-direction: column; align-items: center; text-align: center;">
                <div style="width: 100%; max-width: 280px; aspect-ratio: 4/5; overflow: hidden; border-radius: 140px 140px 0 0; margin-bottom: 2rem; position: relative;">
                  <img src="<?= e($p['img'] ?? '') ?>" alt="<?= e($p['name'] ?? '') ?>" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                </div>
                
                <h3 style="font-family: var(--font-display); font-size: 2rem; font-weight: 400; color: var(--color-primary); margin-bottom: 0.5rem;"><?= e($p['name'] ?? '') ?></h3>
                
                <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                  <span style="width: 20px; height: 1px; background: var(--color-secondary);"></span>
                  <span style="font-family: var(--font-body); font-size: 0.9rem; font-weight: 600; color: var(--color-secondary);"><?= $p['price'] ?? '' ?> Bs.</span>
                  <span style="width: 20px; height: 1px; background: var(--color-secondary);"></span>
                </div>

                <p style="font-size: 0.95rem; color: var(--color-ink-soft); line-height: 1.6; font-weight: 300; margin-bottom: 2rem;"><?= e($p['desc'] ?? '') ?></p>
                
                <a href="catalogo.php" class="btn btn--ghost" style="border-color: var(--color-primary);">Ver más</a>
              </article>
            <?php endforeach; ?>
          <?php else: ?>
            <p style="grid-column: 1 / -1; text-align: center; color: var(--color-ink-soft);">Aún no hay productos en la base de datos. Agrega uno nuevo desde el panel de administración.</p>
          <?php endif; ?>
        </div>
      </div>
    </section>

  </main>

  <?php include __DIR__ . '/includes/footer.php'; ?>

  <script>
    // --- LÓGICA DEL SLIDER ---
    let currentSlide = 0;
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    let slideInterval;

    function goToSlide(index) {
      if(slides.length === 0) return;
      slides[currentSlide].classList.remove('active');
      dots[currentSlide].classList.remove('active');
      currentSlide = index;
      slides[currentSlide].classList.add('active');
      dots[currentSlide].classList.add('active');
      clearInterval(slideInterval);
      startSlider();
    }

    function nextSlide() {
      let next = (currentSlide + 1) % slides.length;
      goToSlide(next);
    }

    function startSlider() {
      slideInterval = setInterval(nextSlide, 5000);
    }

    if(slides.length > 0) startSlider();

    // --- LÓGICA PARA REGISTRAR CLICS DE WHATSAPP ---
    document.addEventListener('DOMContentLoaded', function() {
      document.querySelectorAll('a[href*="wa.me"]').forEach(btn => {
        btn.addEventListener('click', function() {
          // Enviamos la petición al servidor sin recargar la página
          fetch('registrar_whatsapp.php').catch(err => console.log('Error tracking:', err));
        });
      });
    });
  </script>
</body>
</html>
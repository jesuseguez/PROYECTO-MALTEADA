<?php
/**
 * Header Premium
 * by Jesus Eguez
 */
// Incluimos auth para saber si el usuario está logueado
require_once __DIR__ . '/../config/auth.php';
?>
<header class="site-header" id="siteHeader">
  <div class="container site-header__inner">
    <a href="index.php" class="brand">
      <span class="brand__mark"><span class="material-symbols-outlined">icecream</span></span>
      <span class="brand__text">
        <span class="brand__name">Curupau</span>
        <span class="brand__tagline"><?= SITE_TAGLINE ?></span>
      </span>
    </a>

    <?php include __DIR__ . '/navigation.php'; ?>

    <div class="header-actions">
      <!-- Botón de Ingresar / Mi Panel -->
      <a href="<?= isLoggedIn() ? 'admin/dashboard.php' : 'login.php' ?>" class="btn-login">
        <span class="material-symbols-outlined">person</span>
        <span class="login-label"><?= isLoggedIn() ? 'Mi Panel' : 'Ingresar' ?></span>
      </a>
      
      <!-- Botón Menú Móvil -->
      <button class="menu-toggle" aria-label="Menú">
        <span class="material-symbols-outlined">menu</span>
      </button>
    </div>
  </div>
</header>

<!-- Menú Móvil -->
<aside class="mobile-drawer" id="mobileDrawer">
  <nav class="mobile-nav">
    <?php foreach ($navItems as $item): ?>
      <?php $hasSub = !empty($item['submenu']); ?>
      <div class="mobile-nav-item">
        <?php if ($hasSub): ?>
          <button class="mobile-nav-link mobile-nav-toggle" aria-expanded="false">
            <span><?= e($item['label']) ?></span>
            <span class="material-symbols-outlined">expand_more</span>
          </button>
          <div class="mobile-nav-sublist">
            <?php foreach ($item['submenu'] as $sub): ?>
              <a href="<?= e($sub['href']) ?>" class="mobile-nav-sublink">
                <span class="material-symbols-outlined"><?= e($sub['icon']) ?></span>
                <?= e($sub['label']) ?>
              </a>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <a href="<?= e($item['href']) ?>" class="mobile-nav-link <?= is_active($item['key'], $currentPage) ?>">
            <?= e($item['label']) ?>
          </a>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </nav>
</aside>
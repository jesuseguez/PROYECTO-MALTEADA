<?php
return [
    'tradicionales' => [
        [
            'name' => 'Malteada Clásica',
            'desc' => 'Yuca josesana, canela de Ceilán, clavo de olor y leche de estancia.',
            'price' => 22,
            'badge' => 'Original',
            'img' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuBccyUAO-SzTRO5tUTLU0VX4EfyRybtXzupLToKM00cTWFvXsUnzoMqVQug6Q3BAIV_q7R1WFiJ8wUgR9XaJFYyyXej6RKfj33t_QpZBGWF1tCbvJW5tPmGIHVm7QdW85MGqyotrld-xz3qx732qisbZOouLGoAZczglCmillABkCSN-aZJeYU08mu_O23EAOZbGO26dv5Z0Fwh8pkyMnN6QeC_245hqilC3msMsywrkQzC5bwWCX0',
        ],
        [
            'name' => 'Coco Tostado',
            'desc' => 'Horneado en barro chiquitano con leche condensada artesanal.',
            'price' => 25,
            'badge' => 'Favorita',
            'img' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuD-KXkpr7cGGhPTm7flhatI9qoO5PjecfMeTxy_atTv1gtE7od6_e2aOwbe2iV0z2olvLLXAsGM_hKdts3WfFFRCX1SxMRvbtyQ6uikQ9YpPgkHe4OcxKvyNWgYD4mRtpQu40ysZqTtxjLob9xO2e4e8dnJrhXeiOx0u-LCV5M2aIuvur7jBsVSWdxnvAUlHefz11sXN1ZbjmD5iNHzOa9dVLV0S7WgIqIXNmgSUOMaNCYbwp4MHck',
        ]
    ],
    'frutas' => [
        [
            'name' => 'Maracuyá Silvestre',
            'desc' => 'El contraste perfecto entre cremosidad y acidez tropical.',
            'price' => 26,
            'badge' => 'Refrescante',
            'img' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuD68-6Kl74tmq4b1iCPBvPRZ3DSyg60_vRc_7gJVYz-yTdf_iiW0c-bl5EORkVPhE62igBz-GqHXTVxkL_gBaKCe30PV0m4pxQc7Ll8u6Afb5AGAIM6ge7_wzfse0T72vyWJpMvjKA0wOAh7sY8MH7DVvxdB2U9oJ9KUPqrJTo1rgr1yPIxr27ap7_LepTwZ0DJoAfitgIE19fzN8WoH3AupNTIXoGyZ7GxKmso_5U0R5bzEwH4FR8',
        ]
    ],
    'temporada' => [
        [
            'name' => 'Achachairú',
            'desc' => 'Joya del monte cruceño. Pulpa fresca agridulce.',
            'price' => 28,
            'badge' => 'Limitada',
            'img' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuD_l34JhYELlUCkpDoqfmokfq1cIwVkhFpDy5KkYu4yniHz2g4acKfB6RufvGx937nc1l__KYk60XGsFizsg9C7Si-3kZ3p1J4Ovw9iEzXqmrt1_TlZRffTG8yUFupGLLm95ZEgI7xkHb4N6mB4Kwm8LAATbzEvshpWm5iHu2sJh_CFs9FS1XT5Qf8-z4f0UgBiFge5N0Dv52p0vMVKrIkkLQ7Exgudd_5jLES9IWp-4wIIq2zwp8o',
        ]
    ]
];
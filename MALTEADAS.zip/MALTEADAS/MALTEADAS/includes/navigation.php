<?php
$navItems = [
    ['label' => 'Inicio', 'href' => 'index.php', 'key' => 'inicio'],
    [
        'label' => 'Catálogo', 'href' => 'catalogo.php', 'key' => 'catalogo',
        'submenuTitle' => 'Explora nuestra carta',
        'submenu' => [
            ['label' => 'Malteadas Tradicionales', 'desc' => 'La receta original', 'href' => 'catalogo.php#tradicionales', 'icon' => 'icecream'],
            ['label' => 'Frutas de la Chiquitania', 'desc' => 'Achachairú, copoazú', 'href' => 'catalogo.php#frutas', 'icon' => 'eco'],
            ['label' => 'Ediciones de Temporada', 'desc' => 'Sabores limitados', 'href' => 'catalogo.php#temporada', 'icon' => 'auto_awesome'],
        ],
    ],
    ['label' => 'Contacto', 'href' => 'contacto.php', 'key' => 'contacto'],
];
?>
<nav class="nav-primary">
  <?php foreach ($navItems as $item): ?>
    <?php $hasSub = !empty($item['submenu']); ?>
    <div class="nav-item<?= $hasSub ? ' has-submenu' : '' ?>">
      <?php if ($hasSub): ?>
        <button class="nav-link" aria-expanded="false">
          <?= e($item['label']) ?>
          <span class="material-symbols-outlined nav-chevron">expand_more</span>
        </button>
        <div class="nav-submenu">
          <?php if (!empty($item['submenuTitle'])): ?>
            <div class="nav-submenu-header"><?= e($item['submenuTitle']) ?></div>
          <?php endif; ?>
          <?php foreach ($item['submenu'] as $sub): ?>
            <a href="<?= e($sub['href']) ?>" class="nav-submenu__link">
              <span class="material-symbols-outlined"><?= e($sub['icon']) ?></span>
              <span class="nav-submenu__label">
                <?= e($sub['label']) ?>
                <span class="nav-submenu__desc"><?= e($sub['desc']) ?></span>
              </span>
            </a>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <a href="<?= e($item['href']) ?>" class="nav-link <?= is_active($item['key'], $currentPage) ?>"><?= e($item['label']) ?></a>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</nav>
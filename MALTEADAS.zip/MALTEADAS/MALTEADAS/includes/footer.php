<?php
/**
 * Footer Premium
 * by Jesus Eguez
 */
?>
<footer class="site-footer">
  <div class="footer-ribbon">
    <div class="container footer-ribbon__inner">
      <span class="material-symbols-outlined">spa</span>
      <span>Cuna de la Cruceñidad · Misiones Jesuíticas · Tradición Viva</span>
      <span class="material-symbols-outlined">spa</span>
    </div>
  </div>

  <div class="container footer-main">
    <div class="footer-col footer-col--brand">
      <div class="brand">
        <span class="brand__mark"><span class="material-symbols-outlined">icecream</span></span>
        <span class="brand__text">
          <span class="brand__name">Curupau</span>
          <span class="brand__tagline"><?= SITE_TAGLINE ?></span>
        </span>
      </div>
      <p class="footer-text">
        Sabores auténticos de la Chiquitania. Malteadas a base de yuca criolla, frutas silvestres y helados artesanales que celebran nuestras raíces jesuíticas.
      </p>
      <div class="footer-social">
        </a>
      </div>
    </div>

    <div class="footer-col">
      <h3 class="footer-heading">Explorar</h3>
      <ul class="footer-links">
        <li><a href="index.php" class="footer-link"><span class="material-symbols-outlined">arrow_forward</span>Inicio</a></li>
        <li><a href="catalogo.php" class="footer-link"><span class="material-symbols-outlined">arrow_forward</span>Catálogo</a></li>
        <li><a href="contacto.php" class="footer-link"><span class="material-symbols-outlined">arrow_forward</span>Contacto</a></li>
      </ul>
    </div>

    <div class="footer-col">
      <h3 class="footer-heading">Horarios</h3>
      <p class="footer-text">
        <strong>Lun — Vie</strong><br>09:00 — 13:00 · 15:30 — 22:00
      </p>
      <p class="footer-text">
        <strong>Sáb — Dom</strong><br>08:30 — 22:30 (Continuo)
      </p>
    </div>

    <div class="footer-col">
      <h3 class="footer-heading">Visítanos</h3>
      <p class="footer-text"><?= ADDRESS ?></p>
      <p style="margin-top:.75rem">
        <a href="tel:+59139722045" class="footer-link">
          <span class="material-symbols-outlined">call</span><?= PHONE_FIJO ?>
        </a>
      </p>
      <p>
        <a href="mailto:<?= EMAIL_CONTACT ?>" class="footer-link">
          <span class="material-symbols-outlined">mail</span><?= EMAIL_CONTACT ?>
        </a>
      </p>
    </div>
  </div>

  <div class="footer-bottom">
    <div class="container footer-bottom__inner">
      <p>© <?= SITE_YEAR ?> <?= SITE_NAME ?>. Todos los derechos reservados.</p>
      <p class="footer-bottom__credit">
      </p>
    </div>
  </div>
</footer>

<!-- Script ÚNICO -->
<script src="/MALTEADAS/MALTEADAS/assets/js/main.js" defer></script>
</body>
</html>
<?php
echo password_hash('lorena123', PASSWORD_BCRYPT);
?>
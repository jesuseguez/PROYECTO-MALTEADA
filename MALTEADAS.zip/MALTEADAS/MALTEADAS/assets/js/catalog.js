/**
 * Catálogo — Filtros y búsqueda
 * by Jesus Eguez
 */
(function () {
  'use strict';

  const grid = document.getElementById('catalogGrid');
  const empty = document.getElementById('catalogEmpty');
  const search = document.getElementById('catalogSearch');
  const pills = document.querySelectorAll('.filter-pill');

  if (!grid) return;

  let activeCategory = 'todas';
  let activeQuery = '';

  const applyFilters = () => {
    const cards = grid.querySelectorAll('.product-card');
    let visible = 0;

    cards.forEach((card) => {
      const categoryMatch = activeCategory === 'todas' || card.dataset.category === activeCategory;
      const queryMatch = !activeQuery || card.dataset.name.includes(activeQuery);
      const show = categoryMatch && queryMatch;
      card.style.display = show ? '' : 'none';
      if (show) visible++;
    });

    if (empty) empty.hidden = visible > 0;
  };

  pills.forEach((pill) => {
    pill.addEventListener('click', () => {
      pills.forEach((p) => p.classList.remove('is-active'));
      pill.classList.add('is-active');
      activeCategory = pill.dataset.category;
      applyFilters();
    });
  });

  search?.addEventListener('input', (e) => {
    activeQuery = e.target.value.toLowerCase().trim();
    applyFilters();
  });
})();
document.addEventListener('DOMContentLoaded', function() {
  // 1. Header Scroll
  const header = document.querySelector('.site-header');
  if (header) {
    window.addEventListener('scroll', function() {
      if (window.scrollY > 12) header.classList.add('is-scrolled');
      else header.classList.remove('is-scrolled');
    });
  }

  // 2. Submenús Desktop
  const navItems = document.querySelectorAll('.nav-item.has-submenu');
  navItems.forEach(function(item) {
    item.addEventListener('mouseover', function() {
      navItems.forEach(function(i) { i.classList.remove('is-open'); });
      item.classList.add('is-open');
    });
    item.addEventListener('mouseout', function() {
      item.classList.remove('is-open');
    });
  });

  // 3. Menú Móvil
  const menuToggle = document.querySelector('.menu-toggle');
  const drawer = document.querySelector('.mobile-drawer');
  if (menuToggle && drawer) {
    menuToggle.addEventListener('click', function() {
      const isOpen = drawer.classList.toggle('is-open');
      menuToggle.innerHTML = '<span class="material-symbols-outlined">' + (isOpen ? 'close' : 'menu') + '</span>';
    });
  }
});
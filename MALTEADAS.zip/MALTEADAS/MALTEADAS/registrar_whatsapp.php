<?php
/**
 * Registra el clic en WhatsApp de forma segura
 */
require_once __DIR__ . '/config/database.php';

try {
    $hoy = date('Y-m-d');
    // ON DUPLICATE KEY UPDATE asegura que si ya existe la fecha, no dé error, solo ignore.
    $stmt = $pdo->prepare("INSERT INTO clicks_whatsapp (fecha) VALUES (?) ON DUPLICATE KEY UPDATE fecha = fecha");
    $stmt->execute([$hoy]);
    echo "ok"; // Respuesta para el JS
} catch (Exception $e) {
    http_response_code(500);
    echo "error";
}
?>
<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$pageTitle = 'Contacto · ' . SITE_NAME;
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $motivo = trim($_POST['motivo'] ?? '');
    $mensaje = trim($_POST['mensaje'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');

    if ($nombre && $email && $mensaje) {
        try {
            $sql = "INSERT INTO mensajes (nombre, email, motivo, mensaje, telefono) VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            if ($stmt->execute([$nombre, $email, $motivo, $mensaje, $telefono])) {
                $success = '¡Mensaje enviado con éxito! Te responderemos a la brevedad.';
            }
        } catch (PDOException $e) {
            $error = 'Hubo un error al enviar el mensaje. Inténtalo de nuevo.';
        }
    } else {
        $error = 'Por favor completa los campos obligatorios.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <?php include __DIR__ . '/includes/head.php'; ?>
</head>
<body style="background-color: var(--color-surface-muted); margin: 0;">

  <?php include __DIR__ . '/includes/header.php'; ?>

  <main class="page-main" style="padding-top: calc(var(--header-height) + 2rem);">
    
    <section style="padding: 4rem 0 5rem; text-align: center;">
      <div class="container">
        <span class="eyebrow">Atención al Cliente</span>
        <h1 style="font-family: var(--font-display); font-size: clamp(2.5rem, 5vw, 4.5rem); font-weight: 400; color: var(--color-primary); margin: 1rem 0;">
          Estamos para <em style="color: var(--color-secondary);">escucharte</em>
        </h1>
        <p style="color: var(--color-ink-soft); font-size: 1.1rem; max-width: 600px; margin: 0 auto; font-weight: 300; line-height: 1.6;">
          ¿Tienes alguna consulta, duda existencial sobre nuestros sabores o una mala experiencia que quieras reportar? Tu opinión nos ayuda a mejorar cada día.
        </p>
      </div>
    </section>

    <section style="padding: 0 0 8rem;">
      <div class="container">
        <div style="max-width: 800px; margin: 0 auto; background: var(--color-surface); padding: 4rem; border: 1px solid var(--color-line); box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05);">
          
          <div style="margin-bottom: 3rem; text-align: center;">
            <h2 style="font-family: var(--font-display); font-size: 2.5rem; color: var(--color-primary); margin-bottom: 1rem;">Déjanos tu mensaje</h2>
            <p style="color: var(--color-ink-soft); font-size: 0.95rem; font-weight: 300;">Te responderemos a la brevedad posible.</p>
          </div>

          <?php if ($success): ?><div style="background: #d1e7dd; color: #0f5132; padding: 1rem; margin-bottom: 2rem; text-align: center;"><?= $success ?></div><?php endif; ?>
          <?php if ($error): ?><div style="background: #ffdad6; color: #93000a; padding: 1rem; margin-bottom: 2rem; text-align: center;"><?= $error ?></div><?php endif; ?>

          <form method="POST" action="" style="display: flex; flex-direction: column; gap: 2rem;">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
              <div>
                <label style="display: block; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft); margin-bottom: 0.75rem;">Nombre Completo *</label>
                <input type="text" name="nombre" required placeholder="Ej. Mariana Soliz" style="width: 100%; padding: 1.2rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; font-family: var(--font-body); font-size: 0.95rem;">
              </div>
              <div>
                <label style="display: block; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft); margin-bottom: 0.75rem;">Correo Electrónico *</label>
                <input type="email" name="email" required placeholder="mariana@ejemplo.bo" style="width: 100%; padding: 1.2rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; font-family: var(--font-body); font-size: 0.95rem;">
              </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
              <div>
                <label style="display: block; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft); margin-bottom: 0.75rem;">Teléfono / WhatsApp (Opcional)</label>
                <input type="tel" name="telefono" placeholder="+591 70000000" style="width: 100%; padding: 1.2rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; font-family: var(--font-body); font-size: 0.95rem;">
              </div>
              <div>
                <label style="display: block; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft); margin-bottom: 0.75rem;">Motivo de tu mensaje</label>
                <select name="motivo" style="width: 100%; padding: 1.2rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; font-family: var(--font-body); font-size: 0.95rem; appearance: none; cursor: pointer;">
                  <option value="Consulta">Cualquier consulta o duda</option>
                  <option value="Mala Experiencia">Reportar una mala experiencia</option>
                  <option value="Felicitación">Dejar una felicitación</option>
                  <option value="Sugerencia">Sugerencia de nuevo sabor</option>
                </select>
              </div>
            </div>

            <div>
              <label style="display: block; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-ink-soft); margin-bottom: 0.75rem;">Tu Mensaje *</label>
              <textarea name="mensaje" rows="6" required placeholder="Escribe aquí los detalles de tu consulta..." style="width: 100%; padding: 1.2rem; border: 1px solid var(--color-line-strong); background: var(--color-surface-muted); outline: none; font-family: var(--font-body); font-size: 0.95rem; resize: vertical;"></textarea>
            </div>

            <div style="text-align: center; margin-top: 1rem;">
              <button type="submit" class="btn" style="background: var(--color-primary); color: #fff; border: 1px solid var(--color-primary); padding: 1.2rem 4rem; font-size: 0.85rem;">
                Enviar Mensaje
              </button>
            </div>

          </form>

        </div>
      </div>
    </section>

  </main>

  <?php include __DIR__ . '/includes/footer.php'; ?>
</body>
</html>